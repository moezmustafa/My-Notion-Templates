# Timeline View

This view lets you create a Timeline for a project. Notion currently limits the Free plan to 3 timelines, and Team plans to 5. For that reason, I'm not including a Timeline view in the primary project template in order to prevent you from running into problems. If you're on a plan that limits Timelines, you can use this view - just change the Filters to target your intended project. By default, it targets [Website Redesign [DEMO PROJECT]](https://www.notion.so/Website-Redesign-DEMO-PROJECT-b2639aca8e504b6ca1f2d6742dc8e8ff).

In this view, Daily Tasks is hidden in a toggle to allow the Timeline view to have as much horizontal space as possible.

Note that this timeline view uses the Start property for task start dates, and Due for end dates. Start is hidden elsewhere in Ultimate tasks, but you can easily unhide it in any view and use it if you care to add start dates to your non-Timeline views. *Note that tasks without a Start date will not be displayed on the timeline unless you have the left-hand table displaying.* 

**[Inbox](Inbox%203e8bbe137f6e417a848a8c247c8f8b9c.md)   |   [Today](Today%20aa87636a51804ae1bef2813b1629998e.md)   |   [Tomorrow](Tomorrow%20e5c4107edd8c4d30999da5554cc8fa89.md)   |   [7 Days](Next%207%20Days%20311060a093a94811a21ecc1400fc88f7.md)**

- **Daily Tasks**

    [Daily Tasks](Timeline%20View%209da36fe6e98e4aef9b26d68341592124/Daily%20Tasks%201d5af9f3504b4c35937c46a32e3bb93c.csv)

    [Daily Tasks Archive](Daily%20Tasks%20Archive%2075031ec3b1fc4e88ad45756661e95fd8.md) 

[All Tasks](Timeline%20View%209da36fe6e98e4aef9b26d68341592124/All%20Tasks%2092073d9e396944a5b042a9f441913166.csv)