# Write About page copy

Created: Feb 24, 2021 7:43 PM
Created By: Thomas Frank
Done: No
Due: Dec 8, 2020
Edited: Feb 24, 2021 7:43 PM
Inbox: Yes
Kanban - State: To Do
Kanban - Tag: Copy
Priority: 🧀 Medium
Start: Oct 28, 2020
State: 🔴
Sub-Tasks: Sub-Task%20Example%20ac8f452a417443fda1542f111afa0718.md, Overdue%20Sub-Task%20Example%206d390a50672b4676986a8459df6ce969.md
Type: ⏳One-Time

[All Tasks](Write%20About%20page%20copy%20974a9042fff3493fb4c59df961650fcd/All%20Tasks%20ac30254d05624516b45ec36ee0c825a5.csv)