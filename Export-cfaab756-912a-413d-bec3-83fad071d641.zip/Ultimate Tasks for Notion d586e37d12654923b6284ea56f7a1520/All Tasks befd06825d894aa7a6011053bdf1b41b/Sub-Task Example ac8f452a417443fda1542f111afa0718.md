# Sub-Task Example

Created: Feb 24, 2021 7:43 PM
Created By: Thomas Frank
Done: No
Due: Nov 25, 2020
Edited: Feb 24, 2021 7:43 PM
Inbox: Yes
Kanban - State: To Do
Next Due: Feb 28, 2021
Parent Task: Write%20About%20page%20copy%20974a9042fff3493fb4c59df961650fcd.md
Priority: 🧀 Medium
Recur Interval (Days): 5
State: ➞🔴
Type: 🔄Recurring