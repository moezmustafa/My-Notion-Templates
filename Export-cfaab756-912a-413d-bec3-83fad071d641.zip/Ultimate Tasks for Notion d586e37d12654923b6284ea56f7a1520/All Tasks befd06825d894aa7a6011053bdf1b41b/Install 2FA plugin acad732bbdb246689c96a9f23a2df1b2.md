# Install 2FA plugin

Created: Feb 24, 2021 7:43 PM
Created By: Thomas Frank
Done: No
Due: Oct 27, 2020
Edited: Feb 24, 2021 7:43 PM
Inbox: No
Kanban - State: To Do
Kanban - Tag: Security
Priority: 🧀 Medium
Start: Oct 26, 2020
State: 🔴
Type: ⏳One-Time