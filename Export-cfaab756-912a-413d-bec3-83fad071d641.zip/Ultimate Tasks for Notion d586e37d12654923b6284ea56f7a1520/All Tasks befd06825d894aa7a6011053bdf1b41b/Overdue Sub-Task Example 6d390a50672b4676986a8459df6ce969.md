# Overdue Sub-Task Example

Created: Feb 24, 2021 7:43 PM
Created By: Thomas Frank
Done: Yes
Due: Oct 24, 2020
Edited: Feb 24, 2021 7:43 PM
Inbox: Yes
Kanban - State: To Do
Parent Task: Write%20About%20page%20copy%20974a9042fff3493fb4c59df961650fcd.md
Priority: 🚨HIGH
State: ➞🔴
Type: ⏳One-Time