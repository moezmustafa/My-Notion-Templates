# Task Due Today

Created: Feb 24, 2021 7:43 PM
Created By: Thomas Frank
Done: No
Due: Nov 24, 2020
Edited: Feb 24, 2021 7:43 PM
Inbox: Yes
Kanban - State: To Do
Next Due: Feb 26, 2021
Priority: 🧊 Low
Recur Interval (Days): 2
State: 🔴
Type: 🔄Recurring