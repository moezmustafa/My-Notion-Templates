# Take new picture for homepage background

Created: Feb 24, 2021 7:43 PM
Created By: Thomas Frank
Done: No
Due: Nov 26, 2020
Edited: Feb 24, 2021 7:43 PM
Inbox: Yes
Kanban - State: To Do
Kanban - Tag: Design
Priority: 🧀 Medium
Start: Oct 27, 2020
State: 🔴
Type: ⏳One-Time