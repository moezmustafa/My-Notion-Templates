# Create Home Page

Created: Feb 24, 2021 7:43 PM
Created By: Thomas Frank
Done: No
Due: Oct 27, 2020
Edited: Feb 24, 2021 7:43 PM
Inbox: No
Kanban - State: Doing
Kanban - Tag: Design
Priority: 🧀 Medium
Start: Oct 23, 2020
State: 🔴
Type: ⏳One-Time