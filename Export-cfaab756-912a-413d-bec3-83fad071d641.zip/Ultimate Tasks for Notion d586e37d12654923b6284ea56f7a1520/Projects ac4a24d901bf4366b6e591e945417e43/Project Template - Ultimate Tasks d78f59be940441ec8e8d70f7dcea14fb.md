# Project Template - Ultimate Tasks

Archive: No
Created: Feb 24, 2021 7:43 PM
Edited: Feb 24, 2021 7:43 PM
Status: To Do

**Project Overview:** [Add an overview and main goals here]

- Project Info

    Add project details directly here, or link to a note with details elsewhere in your workspace. If you use my [Ultimate Note-Taking System template](https://thomasjfrank.com/templates/notion-note-taking-template/), you could easily create a "Projects" notebook, and then add a Relation for it to the Master Task Database! I'll be teaching this concept in detail in my upcoming [Notion course](https://thomasjfrank.com/notioncourse).

    [Example Note (With Instructions!)](https://www.notion.so/Example-Note-With-Instructions-33d1a8bbfaab471096c87ba7cd428e30) (This is linking to a note within my note-taking system template. Feel free to delete it and link to your own notes.)

[All Tasks](Project%20Template%20-%20Ultimate%20Tasks%20d78f59be940441ec8e8d70f7dcea14fb/All%20Tasks%20986fc1873d6a43ac9b6aa1b3d770e811.csv)