# Priority View

The Priority View lets you sort and view tasks by their priority level. No matter where they're created, all tasks are given Medium priority by default.

**[Inbox](Inbox%203e8bbe137f6e417a848a8c247c8f8b9c.md)   |   [Today](Today%20aa87636a51804ae1bef2813b1629998e.md)   |   [Tomorrow](Tomorrow%20e5c4107edd8c4d30999da5554cc8fa89.md)   |   [7 Days](Next%207%20Days%20311060a093a94811a21ecc1400fc88f7.md)**

[All Tasks](Priority%20View%20b54c6d29f5ce4905aa20c2df20dd6d45/All%20Tasks%204994bc839d6446018f6ea92fbb027db4.csv)

[Daily Tasks](Priority%20View%20b54c6d29f5ce4905aa20c2df20dd6d45/Daily%20Tasks%20be4f93d8d0cd4db49ac44deccfa28204.csv)

[Daily Tasks Archive](Daily%20Tasks%20Archive%2075031ec3b1fc4e88ad45756661e95fd8.md)